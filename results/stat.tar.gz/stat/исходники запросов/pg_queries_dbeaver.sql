-- =====================================================================================================================
-- Статистика запросов к выбранному индексу (для подготовки НТ). Версия для DBeaver.
-- Выполнять под read-only пользователем. Изменений в БД не производится:
-- создаются только временные таблицы (TEMP TABLE), которые удаляются при закрытии сессии.
--
-- Как запускать:
--   1. Открыть SQL-редактор на нужной БД, включить режим Auto-Commit
--      (в ручном режиме любая ошибка оставит транзакцию в состоянии aborted и остальные запросы упадут).
--   2. Задать параметры в блоке "ПАРАМЕТРЫ" ниже (больше нигде в скрипте значения менять не нужно):
--        schema_name - схема сервиса (значение arqs_schema из liquibase)
--        idx         - имя индекса (archive_query_targets.target_external_name)
--        dt_from     - начало периода анализа
--        dt_to       - конец периода анализа
--   3. Выполнить весь скрипт: "Execute SQL Script" (Alt+X).
--      Результаты всех разделов складываются во временную таблицу nt_out, последний запрос скрипта
--      склеивает их в ОДНУ ячейку текста (разделы с заголовками "=== N ...", колонки через табуляцию).
--   4. Скопировать результат: во вкладке последнего запроса выделить ячейку report и нажать Ctrl+C
--      (или открыть ячейку в панели значений, Shift+Enter / F7, и скопировать оттуда), вставить в текстовый файл.
--      Если ячейка копируется обрезанной - выполнить закомментированный вариант в конце скрипта
--      (по строке на строку отчёта), нажать "Fetch all rows" и скопировать Ctrl+A, Ctrl+C.
--
-- КОНФИДЕНЦИАЛЬНОСТЬ: значения фильтров в результаты не попадают.
--   * все строковые литералы в тексте запроса заменяются на ?, кроме имён параметров
--     в конструкции ARRAY_POSITION("paramName", '<имя параметра>');
--   * все числовые литералы заменяются на ? (кроме смещения "- 1" в обращении к массиву параметров);
--   * списки IN (?, ?, ...) сворачиваются в IN (?...), длина списка выводится отдельно;
--   * логины пользователей не выводятся (только количество и обезличенное распределение);
--   * поле final_sql_query не используется (в нём подставлены значения из файлов условий).
-- =====================================================================================================================

-- ---------------------------------------------------------------------------------------------------------------------
-- ПАРАМЕТРЫ
-- ---------------------------------------------------------------------------------------------------------------------
DROP TABLE IF EXISTS nt_params;
CREATE TEMP TABLE nt_params AS
SELECT 'arqs'::text            AS schema_name,
       'my_index'::text        AS idx,
       '2026-07-01'::timestamp AS dt_from,
       '2026-10-01'::timestamp AS dt_to;

-- схема сервиса в search_path (на уровне сессии)
SELECT set_config('search_path', schema_name, false) AS search_path FROM nt_params;

-- ---------------------------------------------------------------------------------------------------------------------
-- Базовая временная таблица: запросы к индексу + нормализованный (обезличенный) шаблон SQL
-- ---------------------------------------------------------------------------------------------------------------------
DROP TABLE IF EXISTS nt_q;
CREATE TEMP TABLE nt_q AS
WITH q AS (
    SELECT aq.*
    FROM archive_queries aq
    CROSS JOIN nt_params p
    WHERE aq.created_ts >= p.dt_from
      AND aq.created_ts <  p.dt_to
      AND EXISTS (SELECT 1
                  FROM archive_query_targets t
                  WHERE t.archive_query_id = aq.archive_query_id
                    AND t.target_type = 'INDEX'
                    AND t.target_external_name = p.idx)
),
s1 AS (   -- 1. защищаем имя параметра в ARRAY_POSITION(<колонка>, '<имя>') маркером
    SELECT q.*,
           regexp_replace(q.sql_query,
                          '(ARRAY_POSITION\s*\(\s*[^,()]*,\s*)''([^'']*)''',
                          '\1#P#\2#/P#', 'gi') AS t
    FROM q
),
s2 AS (   -- 2. маскируем строковые литералы (с учётом экранирования '')
    SELECT s1.*, regexp_replace(t, '''([^'']|'''')*''', '?', 'g') AS t2 FROM s1
),
s3 AS (   -- 3. маскируем числовые литералы (идентификаторы вида "field1" не затрагиваются)
    SELECT s2.*, regexp_replace(t2, '\m\d+(\.\d+)?\M', '?', 'g') AS t3 FROM s2
),
s4r AS (   -- 4. возвращаем смещение "- 1" и имена параметров, нормализуем пробелы
    SELECT s3.*,
           regexp_replace(
               regexp_replace(
                   regexp_replace(t3, '(#/P#\s*\)\s*-\s*)\?', '\11', 'g'),
                   '#P#([^#]*)#/P#', '''\1''', 'g'),
               '\s+', ' ', 'g') AS t4_raw
    FROM s3
),
s4 AS (   -- 4а. убираем завершающие ";" и пробелы, чтобы одинаковые запросы попадали в один шаблон
    SELECT s4r.*, regexp_replace(t4_raw, '[\s;]+$', '') AS t4
    FROM s4r
    OFFSET 0   -- не даёт планировщику встроить CTE и пересчитывать выражения для каждой ссылки
),
s5 AS (   -- 5. сворачиваем списки IN (?, ?, ...) -> IN (?...)
    SELECT s4.*, regexp_replace(t4, 'IN\s*\(\s*\?(\s*,\s*\?)*\s*\)', 'IN (?...)', 'gi') AS t5
    FROM s4
),
s6 AS (   -- 6. полнотекстовый поиск "по всем полям" (UI раскрывает * в OR по всем колонкам, >= 8 условий)
    SELECT s5.*,
           substring(t5 FROM '(\(\s*(CAST\(\\?"[^"\\]+\\?" AS STRING\)|\\?"[^"\\]+\\?")\s+(NOT\s+)?I?LIKE\s+\?(\s+OR\s+(CAST\(\\?"[^"\\]+\\?" AS STRING\)|\\?"[^"\\]+\\?")\s+(NOT\s+)?I?LIKE\s+\?){7,}\s*\))') AS ft
    FROM s5
    OFFSET 0
)
SELECT s6.archive_query_id,
       s6.created_ts,
       s6.final_status_ts,
       s6.status,
       s6.query_type,
       s6.spark_profile_name,
       s6.zone,
       s6.search_from,
       s6.search_to,
       s6.total,
       s6.max_rows,
       s6.volume_bytes,
       s6.complexity,
       s6.retry_count,
       s6.created_user,
       EXTRACT(EPOCH FROM (s6.final_status_ts - s6.created_ts))           AS duration_sec,
       EXTRACT(EPOCH FROM (s6.search_to - s6.search_from)) / 3600.0       AS period_hours,
       s6.t5                                                              AS sql_template_full,
       -- шаблон, где полнотекстовая цепочка заменена маркером: <ПОЛНОТЕКСТ LIKE|ILIKE, N колонок>
       CASE WHEN s6.ft IS NULL THEN s6.t5
            ELSE replace(s6.t5, s6.ft,
                         '(<ПОЛНОТЕКСТ ' || CASE WHEN s6.ft ~ 'ILIKE' THEN 'ILIKE' ELSE 'LIKE' END || ', '
                         || array_length(regexp_split_to_array(s6.ft, '\s+OR\s+'), 1) || ' колонок>)')
       END                                                                AS sql_template,
       CASE WHEN s6.ft IS NULL THEN NULL WHEN s6.ft ~ 'ILIKE' THEN 'ILIKE' ELSE 'LIKE' END AS fulltext_kind,
       (SELECT max(array_length(regexp_split_to_array(m[1], ','), 1))
        FROM regexp_matches(s6.t4, 'IN\s*\(\s*(\?(\s*,\s*\?)*)\s*\)', 'gi') m) AS max_in_list_len,
       (SELECT count(*) FROM archive_query_targets t
        WHERE t.archive_query_id = s6.archive_query_id)                   AS targets_cnt,
       EXISTS (SELECT 1 FROM archive_query_file_conditions fc
               WHERE fc.archive_query_id = s6.archive_query_id)           AS has_file_conditions
FROM s6;

-- ---------------------------------------------------------------------------------------------------------------------
-- Накопитель результатов: каждая строка результата раздела сохраняется как JSON (порядок колонок сохраняется)
-- ---------------------------------------------------------------------------------------------------------------------
DROP TABLE IF EXISTS nt_out;
CREATE TEMP TABLE nt_out (ord int, sec text, title text, rn bigint, j json);

-- =====================================================================================================================
-- 1. Общая сводка
-- =====================================================================================================================
-- === 1.1 Общая сводка
INSERT INTO nt_out
SELECT 1, '1.1', 'Общая сводка', r.rn, r.j
FROM (SELECT 1) one LEFT JOIN (
    SELECT row_number() OVER () AS rn, row_to_json(x) AS j FROM (
        SELECT count(*)                                  AS queries_total,
               min(created_ts)                           AS first_query_ts,
               max(created_ts)                           AS last_query_ts,
               count(DISTINCT created_user)              AS distinct_users,
               count(DISTINCT sql_template)              AS distinct_templates,
               count(*) FILTER (WHERE has_file_conditions) AS with_file_conditions,
               count(*) FILTER (WHERE targets_cnt > 1)   AS multi_target_queries
        FROM nt_q
    ) x
) r ON true;

-- === 1.2 По статусам и типам запросов
INSERT INTO nt_out
SELECT 2, '1.2', 'По статусам и типам запросов', r.rn, r.j
FROM (SELECT 1) one LEFT JOIN (
    SELECT row_number() OVER () AS rn, row_to_json(x) AS j FROM (
        SELECT status, query_type, count(*) AS cnt,
               round(100.0 * count(*) / sum(count(*)) OVER (), 2) AS pct
        FROM nt_q
        GROUP BY status, query_type
        ORDER BY cnt DESC
    ) x
) r ON true;

-- === 1.3 По spark-профилям и зонам
INSERT INTO nt_out
SELECT 3, '1.3', 'По spark-профилям и зонам', r.rn, r.j
FROM (SELECT 1) one LEFT JOIN (
    SELECT row_number() OVER () AS rn, row_to_json(x) AS j FROM (
        SELECT spark_profile_name, zone, count(*) AS cnt,
               round(avg(duration_sec)::numeric, 1) AS avg_duration_sec
        FROM nt_q
        GROUP BY spark_profile_name, zone
        ORDER BY cnt DESC
    ) x
) r ON true;

-- === 1.4 Повторные сабмиты (retry_count)
INSERT INTO nt_out
SELECT 4, '1.4', 'Повторные сабмиты (retry_count)', r.rn, r.j
FROM (SELECT 1) one LEFT JOIN (
    SELECT row_number() OVER () AS rn, row_to_json(x) AS j FROM (
        SELECT coalesce(retry_count, 0) AS retry_count, count(*) AS cnt
        FROM nt_q
        GROUP BY 1
        ORDER BY 1
    ) x
) r ON true;


-- =====================================================================================================================
-- 2. Интенсивность
-- =====================================================================================================================
-- === 2.1 Пиковые часы (топ-20)
INSERT INTO nt_out
SELECT 5, '2.1', 'Пиковые часы (топ-20)', r.rn, r.j
FROM (SELECT 1) one LEFT JOIN (
    SELECT row_number() OVER () AS rn, row_to_json(x) AS j FROM (
        SELECT date_trunc('hour', created_ts) AS hh, count(*) AS cnt
        FROM nt_q
        GROUP BY 1
        ORDER BY cnt DESC
        LIMIT 20
    ) x
) r ON true;

-- === 2.2 Пиковые минуты (топ-20)
INSERT INTO nt_out
SELECT 6, '2.2', 'Пиковые минуты (топ-20)', r.rn, r.j
FROM (SELECT 1) one LEFT JOIN (
    SELECT row_number() OVER () AS rn, row_to_json(x) AS j FROM (
        SELECT date_trunc('minute', created_ts) AS mm, count(*) AS cnt
        FROM nt_q
        GROUP BY 1
        ORDER BY cnt DESC
        LIMIT 20
    ) x
) r ON true;

-- === 2.3 Интервалы между соседними запросами, сек (перцентили)
INSERT INTO nt_out
SELECT 7, '2.3', 'Интервалы между соседними запросами, сек (перцентили)', r.rn, r.j
FROM (SELECT 1) one LEFT JOIN (
    SELECT row_number() OVER () AS rn, row_to_json(x) AS j FROM (
        WITH d AS (
            SELECT EXTRACT(EPOCH FROM created_ts - lag(created_ts) OVER (ORDER BY created_ts)) AS gap_sec
            FROM nt_q
        )
        SELECT count(gap_sec) AS n,
               percentile_cont(ARRAY[0.1, 0.25, 0.5, 0.75, 0.9, 0.99]) WITHIN GROUP (ORDER BY gap_sec) AS p10_25_50_75_90_99,
               min(gap_sec) AS min_gap, max(gap_sec) AS max_gap
        FROM d
    ) x
) r ON true;

-- === 2.4 Максимальная конкурентность по дням, топ-100 (одновременно выполняющихся запросов, от created_ts до final_status_ts)
--     (учитываются только запросы с final_status_ts; запросы без него - в 2.4.1)
INSERT INTO nt_out
SELECT 8, '2.4', 'Максимальная конкурентность по дням, топ-100 (одновременно выполняющихся запросов, от created_ts до final_status_ts)', r.rn, r.j
FROM (SELECT 1) one LEFT JOIN (
    SELECT row_number() OVER () AS rn, row_to_json(x) AS j FROM (
        WITH ev AS (
            SELECT created_ts AS ts, 1 AS delta FROM nt_q WHERE final_status_ts IS NOT NULL
            UNION ALL
            SELECT final_status_ts, -1 FROM nt_q WHERE final_status_ts IS NOT NULL
        ),
        run AS (
            SELECT ts, sum(delta) OVER (ORDER BY ts, delta ROWS UNBOUNDED PRECEDING) AS concurrent
            FROM ev
        )
        SELECT date_trunc('day', ts) AS day, max(concurrent) AS max_concurrent
        FROM run
        GROUP BY 1
        ORDER BY max_concurrent DESC, day
        LIMIT 100
    ) x
) r ON true;

-- === 2.4.1 Запросы без final_status_ts (выполняются или зависли)
INSERT INTO nt_out
SELECT 9, '2.4.1', 'Запросы без final_status_ts (выполняются или зависли)', r.rn, r.j
FROM (SELECT 1) one LEFT JOIN (
    SELECT row_number() OVER () AS rn, row_to_json(x) AS j FROM (
        SELECT status, count(*) AS cnt, min(created_ts) AS oldest_created_ts
        FROM nt_q
        WHERE final_status_ts IS NULL
        GROUP BY status
    ) x
) r ON true;

-- === 2.5 Обезличенное распределение запросов по пользователям
INSERT INTO nt_out
SELECT 10, '2.5', 'Обезличенное распределение запросов по пользователям', r.rn, r.j
FROM (SELECT 1) one LEFT JOIN (
    SELECT row_number() OVER () AS rn, row_to_json(x) AS j FROM (
        WITH u AS (SELECT created_user, count(*) AS cnt FROM nt_q GROUP BY 1)
        SELECT count(*) AS users,
               sum(cnt) AS queries,
               percentile_cont(ARRAY[0.5, 0.9, 0.99]) WITHIN GROUP (ORDER BY cnt) AS p50_90_99_per_user,
               max(cnt) AS max_per_user
        FROM u
    ) x
) r ON true;


-- =====================================================================================================================
-- 3. Длительность и объёмы
-- =====================================================================================================================
-- === 3.1 Длительность выполнения, сек (по статусам)
INSERT INTO nt_out
SELECT 11, '3.1', 'Длительность выполнения, сек (по статусам)', r.rn, r.j
FROM (SELECT 1) one LEFT JOIN (
    SELECT row_number() OVER () AS rn, row_to_json(x) AS j FROM (
        SELECT status, count(*) AS cnt,
               round(min(duration_sec)::numeric, 1) AS min_sec,
               round(avg(duration_sec)::numeric, 1) AS avg_sec,
               percentile_cont(ARRAY[0.5, 0.75, 0.9, 0.95, 0.99]) WITHIN GROUP (ORDER BY duration_sec) AS p50_75_90_95_99,
               round(max(duration_sec)::numeric, 1) AS max_sec
        FROM nt_q
        WHERE duration_sec IS NOT NULL
        GROUP BY status
        ORDER BY cnt DESC
    ) x
) r ON true;

-- === 3.2 Распределение длительности по корзинам (FINISHED и DELETED - выполненные запросы)
INSERT INTO nt_out
SELECT 12, '3.2', 'Распределение длительности по корзинам (FINISHED и DELETED - выполненные запросы)', r.rn, r.j
FROM (SELECT 1) one LEFT JOIN (
    SELECT row_number() OVER () AS rn, row_to_json(x) AS j FROM (
        SELECT CASE
                   WHEN duration_sec < 60    THEN '1) < 1 мин'
                   WHEN duration_sec < 300   THEN '2) 1-5 мин'
                   WHEN duration_sec < 900   THEN '3) 5-15 мин'
                   WHEN duration_sec < 3600  THEN '4) 15-60 мин'
                   WHEN duration_sec < 14400 THEN '5) 1-4 ч'
                   ELSE '6) > 4 ч' END AS bucket,
               count(*) AS cnt
        FROM nt_q
        WHERE status IN ('FINISHED', 'DELETED')
        GROUP BY 1
        ORDER BY 1
    ) x
) r ON true;

-- === 3.3 Глубина периода поиска (search_to - search_from), часы
INSERT INTO nt_out
SELECT 13, '3.3', 'Глубина периода поиска (search_to - search_from), часы', r.rn, r.j
FROM (SELECT 1) one LEFT JOIN (
    SELECT row_number() OVER () AS rn, row_to_json(x) AS j FROM (
        SELECT count(*) AS cnt,
               percentile_cont(ARRAY[0.1, 0.5, 0.75, 0.9, 0.99]) WITHIN GROUP (ORDER BY period_hours) AS p10_50_75_90_99,
               max(period_hours) AS max_hours
        FROM nt_q
    ) x
) r ON true;

INSERT INTO nt_out
SELECT 14, '3.3.b', 'Глубина периода поиска (search_to - search_from), часы (продолжение)', r.rn, r.j
FROM (SELECT 1) one LEFT JOIN (
    SELECT row_number() OVER () AS rn, row_to_json(x) AS j FROM (
        SELECT CASE
                   WHEN period_hours <= 1      THEN '1) <= 1 ч'
                   WHEN period_hours <= 24     THEN '2) <= 1 сут'
                   WHEN period_hours <= 24*7   THEN '3) <= 1 нед'
                   WHEN period_hours <= 24*31  THEN '4) <= 1 мес'
                   WHEN period_hours <= 24*92  THEN '5) <= 3 мес'
                   WHEN period_hours <= 24*366 THEN '6) <= 1 год'
                   ELSE '7) > 1 год' END AS period_bucket,
               count(*) AS cnt,
               round(avg(duration_sec)::numeric, 1) AS avg_duration_sec,
               percentile_cont(0.9) WITHIN GROUP (ORDER BY duration_sec) AS p90_duration_sec
        FROM nt_q
        GROUP BY 1
        ORDER BY 1
    ) x
) r ON true;

-- === 3.4 Насколько далеко в прошлое смотрят запросы (created_ts - search_from), сутки
INSERT INTO nt_out
SELECT 15, '3.4', 'Насколько далеко в прошлое смотрят запросы (created_ts - search_from), сутки', r.rn, r.j
FROM (SELECT 1) one LEFT JOIN (
    SELECT row_number() OVER () AS rn, row_to_json(x) AS j FROM (
        SELECT percentile_cont(ARRAY[0.1, 0.5, 0.9, 0.99]) WITHIN GROUP (
                   ORDER BY EXTRACT(EPOCH FROM created_ts - search_from) / 86400) AS p10_50_90_99_days
        FROM nt_q
    ) x
) r ON true;

-- === 3.5 Найдено записей (total), лимит (max_rows), объём сканирования, сложность
INSERT INTO nt_out
SELECT 16, '3.5', 'Найдено записей (total), лимит (max_rows), объём сканирования, сложность', r.rn, r.j
FROM (SELECT 1) one LEFT JOIN (
    SELECT row_number() OVER () AS rn, row_to_json(x) AS j FROM (
        SELECT count(*) AS cnt,
               percentile_cont(ARRAY[0.5, 0.9, 0.99]) WITHIN GROUP (ORDER BY total)        AS total_p50_90_99,
               max(total)                                                                  AS total_max,
               count(*) FILTER (WHERE total = 0)                                           AS total_zero,
               count(*) FILTER (WHERE max_rows IS NOT NULL AND total >= max_rows)          AS hit_max_rows,
               percentile_cont(ARRAY[0.5, 0.9, 0.99]) WITHIN GROUP (ORDER BY max_rows)     AS max_rows_p50_90_99,
               percentile_cont(ARRAY[0.5, 0.9, 0.99]) WITHIN GROUP (ORDER BY volume_bytes) AS volume_bytes_p50_90_99,
               max(volume_bytes)                                                           AS volume_bytes_max,
               percentile_cont(ARRAY[0.5, 0.9, 0.99]) WITHIN GROUP (ORDER BY complexity)   AS complexity_p50_90_99
        FROM nt_q
        WHERE status IN ('FINISHED', 'DELETED')
    ) x
) r ON true;


-- =====================================================================================================================
-- 4. Шаблоны запросов (значения фильтров замаскированы)
-- =====================================================================================================================
-- === 4.1 Шаблоны запросов, топ-200 по частоте
INSERT INTO nt_out
SELECT 17, '4.1', 'Шаблоны запросов, топ-200 по частоте', r.rn, r.j
FROM (SELECT 1) one LEFT JOIN (
    SELECT row_number() OVER () AS rn, row_to_json(x) AS j FROM (
        SELECT count(*)                                                                    AS cnt,
               round(100.0 * count(*) / sum(count(*)) OVER (), 2)                          AS pct,
               count(*) FILTER (WHERE status IN ('FINISHED', 'DELETED'))                   AS finished,
               count(*) FILTER (WHERE status = 'FAILED')                                   AS failed,
               round(avg(duration_sec)::numeric, 1)                                        AS avg_duration_sec,
               percentile_cont(0.9) WITHIN GROUP (ORDER BY duration_sec)                   AS p90_duration_sec,
               round(avg(period_hours)::numeric, 1)                                        AS avg_period_hours,
               percentile_cont(0.5) WITHIN GROUP (ORDER BY total)                          AS p50_total,
               max(max_in_list_len)                                                        AS max_in_list_len,
               count(*) FILTER (WHERE has_file_conditions)                                 AS with_file_conditions,
               sql_template
        FROM nt_q
        GROUP BY sql_template
        ORDER BY cnt DESC
        LIMIT 200
    ) x
) r ON true;

-- === 4.2 Используемые параметры событий (ARRAY_POSITION(..., <имя>)) и число запросов с ними
INSERT INTO nt_out
SELECT 18, '4.2', 'Используемые параметры событий (ARRAY_POSITION(..., <имя>)) и число запросов с ними', r.rn, r.j
FROM (SELECT 1) one LEFT JOIN (
    SELECT row_number() OVER () AS rn, row_to_json(x) AS j FROM (
        SELECT m[1] AS param_name,
               count(DISTINCT q.archive_query_id) AS queries_cnt,
               round(100.0 * count(DISTINCT q.archive_query_id) / (SELECT count(*) FROM nt_q), 2) AS pct_of_queries
        FROM nt_q q,
             regexp_matches(q.sql_template, 'ARRAY_POSITION\s*\([^,()]*,\s*''([^'']*)''', 'gi') m
        GROUP BY 1
        ORDER BY queries_cnt DESC
    ) x
) r ON true;

-- === 4.3 Поля в WHERE (без полнотекстового поиска - он учтён в 4.5) и число запросов с ними
INSERT INTO nt_out
SELECT 19, '4.3', 'Поля в WHERE (без полнотекстового поиска - он учтён в 4.5) и число запросов с ними', r.rn, r.j
FROM (SELECT 1) one LEFT JOIN (
    SELECT row_number() OVER () AS rn, row_to_json(x) AS j FROM (
        SELECT m[1] AS field,
               count(DISTINCT q.archive_query_id) AS queries_cnt
        FROM nt_q q,
             regexp_matches(regexp_replace(substring(q.sql_template FROM '(?i)\mWHERE\M(.*)$'), '(?i)\mORDER\s+BY\M.*$', ''),
                            '\\?["`]([A-Za-z_][A-Za-z0-9_]*)\\?["`]', 'g') m
        GROUP BY 1
        ORDER BY queries_cnt DESC
    ) x
) r ON true;

-- === 4.4 Списки полей в SELECT
INSERT INTO nt_out
SELECT 20, '4.4', 'Списки полей в SELECT', r.rn, r.j
FROM (SELECT 1) one LEFT JOIN (
    SELECT row_number() OVER () AS rn, row_to_json(x) AS j FROM (
        SELECT substring(sql_template, 1, strpos(lower(sql_template), ' from ') - 1) AS select_list,
               count(*) AS cnt
        FROM nt_q
        GROUP BY 1
        ORDER BY cnt DESC
        LIMIT 50
    ) x
) r ON true;

-- === 4.5 Используемые конструкции
INSERT INTO nt_out
SELECT 21, '4.5', 'Используемые конструкции', r.rn, r.j
FROM (SELECT 1) one LEFT JOIN (
    SELECT row_number() OVER () AS rn, row_to_json(x) AS j FROM (
        SELECT count(*)                                                                  AS total,
               count(*) FILTER (WHERE sql_template ~* '\mWHERE\M')                       AS has_where,
               count(*) FILTER (WHERE sql_template ~* '\mOR\M')                          AS has_or,
               count(*) FILTER (WHERE sql_template ~* '\mIN\s*\(')                       AS has_in,
               count(*) FILTER (WHERE sql_template ~* '\mI?LIKE\M')                      AS has_like,
               count(*) FILTER (WHERE sql_template ~* '\mBETWEEN\M')                     AS has_between,
               count(*) FILTER (WHERE sql_template ~* '\mGROUP\s+BY\M')                  AS has_group_by,
               count(*) FILTER (WHERE sql_template ~* '\mORDER\s+BY\M')                  AS has_order_by,
               count(*) FILTER (WHERE sql_template ~* '\mDISTINCT\M')                    AS has_distinct,
               count(*) FILTER (WHERE sql_template ~* '\mJOIN\M')                        AS has_join,
               count(*) FILTER (WHERE sql_template ~* '\mLIMIT\M')                       AS has_limit,
               count(*) FILTER (WHERE sql_template ~* 'ARRAY_POSITION')                  AS has_param_filter,
               count(*) FILTER (WHERE sql_template ~* '''EPK_ID''')                      AS has_epk_id,
               count(*) FILTER (WHERE fulltext_kind = 'LIKE')                            AS fulltext_like,
               count(*) FILTER (WHERE fulltext_kind = 'ILIKE')                           AS fulltext_ilike
        FROM nt_q
    ) x
) r ON true;

-- === 4.6 Длина списков IN (...)
INSERT INTO nt_out
SELECT 22, '4.6', 'Длина списков IN (...)', r.rn, r.j
FROM (SELECT 1) one LEFT JOIN (
    SELECT row_number() OVER () AS rn, row_to_json(x) AS j FROM (
        SELECT max_in_list_len, count(*) AS cnt
        FROM nt_q
        WHERE max_in_list_len IS NOT NULL
        GROUP BY 1
        ORDER BY 1
    ) x
) r ON true;


-- =====================================================================================================================
-- 5. Условия по файлам (archive_query_file_conditions) - без содержимого файлов
-- =====================================================================================================================
-- === 5.1 Условия по файлам: поля, метод фильтрации, тип связи
INSERT INTO nt_out
SELECT 23, '5.1', 'Условия по файлам: поля, метод фильтрации, тип связи', r.rn, r.j
FROM (SELECT 1) one LEFT JOIN (
    SELECT row_number() OVER () AS rn, row_to_json(x) AS j FROM (
        SELECT fc.fields,
               fc.filter_method,
               fc.condition,
               count(*)                            AS conditions_cnt,
               count(DISTINCT fc.archive_query_id) AS queries_cnt
        FROM archive_query_file_conditions fc
        JOIN nt_q q ON q.archive_query_id = fc.archive_query_id
        GROUP BY fc.fields, fc.filter_method, fc.condition
        ORDER BY queries_cnt DESC
    ) x
) r ON true;

-- === 5.2 Размер файлов условий (байты) и количество условий на запрос
INSERT INTO nt_out
SELECT 24, '5.2', 'Размер файлов условий (байты) и количество условий на запрос', r.rn, r.j
FROM (SELECT 1) one LEFT JOIN (
    SELECT row_number() OVER () AS rn, row_to_json(x) AS j FROM (
        SELECT count(DISTINCT f.file_id)                                              AS files,
               percentile_cont(ARRAY[0.5, 0.9, 0.99]) WITHIN GROUP (ORDER BY f.size)  AS size_p50_90_99,
               max(f.size)                                                            AS size_max
        FROM archive_query_file_conditions fc
        JOIN nt_q q ON q.archive_query_id = fc.archive_query_id
        JOIN archive_query_files f ON f.file_id = fc.file_id
    ) x
) r ON true;

INSERT INTO nt_out
SELECT 25, '5.2.b', 'Размер файлов условий (байты) и количество условий на запрос (продолжение)', r.rn, r.j
FROM (SELECT 1) one LEFT JOIN (
    SELECT row_number() OVER () AS rn, row_to_json(x) AS j FROM (
        SELECT conditions_per_query, count(*) AS queries_cnt
        FROM (SELECT fc.archive_query_id, count(*) AS conditions_per_query
              FROM archive_query_file_conditions fc
              JOIN nt_q q ON q.archive_query_id = fc.archive_query_id
              GROUP BY 1) x
        GROUP BY 1
        ORDER BY 1
    ) x
) r ON true;

-- =====================================================================================================================
-- ИТОГ: весь отчёт одним текстом
-- =====================================================================================================================
WITH cells AS (
    SELECT o.ord, o.rn, e.n, e.k, coalesce(regexp_replace(e.v, '[\t\r\n]+', ' ', 'g'), 'NULL') AS v
    FROM nt_out o, json_each_text(o.j) WITH ORDINALITY e(k, v, n)
),
lines AS (
    -- заголовок раздела
    SELECT ord, 0 AS part, 0::bigint AS rn, '=== ' || sec || ' ' || title AS line FROM nt_out WHERE rn IS NULL OR rn = 1
    UNION ALL
    -- пустой результат
    SELECT ord, 1, 0, '(нет строк)' FROM nt_out WHERE rn IS NULL
    UNION ALL
    -- названия колонок
    SELECT ord, 1, 0, string_agg(k, E'\t' ORDER BY n) FROM cells WHERE rn = 1 GROUP BY ord
    UNION ALL
    -- строки данных
    SELECT ord, 2, rn, string_agg(v, E'\t' ORDER BY n) FROM cells GROUP BY ord, rn
    UNION ALL
    -- пустая строка между разделами
    SELECT ord, 3, 0, '' FROM nt_out WHERE rn IS NULL OR rn = 1
)
SELECT string_agg(line, E'\n' ORDER BY ord, part, rn) AS report
FROM lines;

-- Вариант на случай, если одна большая ячейка копируется обрезанной: отчёт построчно.
-- Перед копированием нажать "Fetch all rows" (по умолчанию DBeaver подгружает только 200 строк).
-- WITH cells AS (
--     SELECT o.ord, o.rn, e.n, e.k, coalesce(regexp_replace(e.v, '[\t\r\n]+', ' ', 'g'), 'NULL') AS v
--     FROM nt_out o, json_each_text(o.j) WITH ORDINALITY e(k, v, n)
-- ),
-- lines AS (
--     SELECT ord, 0 AS part, 0::bigint AS rn, '=== ' || sec || ' ' || title AS line FROM nt_out WHERE rn IS NULL OR rn = 1
--     UNION ALL
--     SELECT ord, 1, 0, '(нет строк)' FROM nt_out WHERE rn IS NULL
--     UNION ALL
--     SELECT ord, 1, 0, string_agg(k, E'\t' ORDER BY n) FROM cells WHERE rn = 1 GROUP BY ord
--     UNION ALL
--     SELECT ord, 2, rn, string_agg(v, E'\t' ORDER BY n) FROM cells GROUP BY ord, rn
--     UNION ALL
--     SELECT ord, 3, 0, '' FROM nt_out WHERE rn IS NULL OR rn = 1
-- )
-- SELECT line AS report FROM lines ORDER BY ord, part, rn;
