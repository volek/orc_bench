orc-bench cluster bundle (Checkpoint 10)
========================================

On the Hadoop/SDP node (not the developer laptop):

  1. tar -xzf orc-bench-cluster-bundle.tgz && cd orc-bench
  2. cp conf/environment.local.yaml.example conf/environment.local.yaml
     # edit executor_* if needed (deploy_mode is cluster only)
  3. Ensure Kerberos ticket/principal is already available; keytab at path from
     conf/environment.yaml for spark-submit --principal/--keytab (do not commit it)
  4. ./scripts/run-preflight.sh --env-override conf/environment.local.yaml
     # cluster mode (default): the script ships that file via spark-submit --files
  5. ./scripts/run-preflight.sh --live --env-override conf/environment.local.yaml
  6. ./scripts/run-pilot-s.sh --phase generate --env-override conf/environment.local.yaml
  7. ./scripts/run-pilot-s.sh --phase materialize --env-override conf/environment.local.yaml
  8. ./scripts/run-pilot-s.sh --phase run --env-override conf/environment.local.yaml
  9. Fill calibration checklist (runbook §12); finalize executor_* / concurrency for S

If scripts fail with ": No such file or directory" (empty path before colon):
  sed -i 's/\r$//' scripts/*.sh scripts/lib/*.sh
  # or: dos2unix scripts/*.sh scripts/lib/*.sh
  Then re-run. Cause is Windows CRLF line endings on *.sh.

Local script logs (stdout+stderr): logs/<script>-YYYYMMDD-HHMMSS.log
  Override: ORC_BENCH_LOG_DIR / ORC_BENCH_LOG_FILE


Jar layout in this bundle (repo root, not build/libs/):
  ./orc-bench-0.1.0-SNAPSHOT-all.jar

Pilot S experiments: conf/pilot-s.yaml
  materialize: BLOOM_SESSION
  run: ORC_COLUMN_PRUNING,ORC_PUSHDOWN,BLOOM_SESSION,SPARK_VECTORIZATION

Deploy mode is cluster only. Scripts reject --deploy-mode client
and spark.deploy_mode: client in environment.local.yaml.

Defaults: yarn / deploy_mode=cluster / queue=default / executors 4×2×3g (archive-query common)

Full ops runbook: docs/Запуск на Hadoop кластере.md (if --with-runbook) or
the repo copy on the developer machine.
